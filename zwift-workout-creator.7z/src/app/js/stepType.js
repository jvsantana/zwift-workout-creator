angular.module("zwiftWorkoutApp")
    .constant("stepType", {
        warmUp: "warmUp",
        coolDown: "coolDown",
        steadyState: "steadyState",
        ramp: "ramp"
    });
